package com.eaibot.demo;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.eaibot.constants.BroadcastFilter;
import com.eaibot.listener.OnTaskListener;
import com.eaibot.ros.RosClient;
import com.eaibot.ros.RosService;

/**
 * Created by EAIBOT on 2018/10/10.
 */

public class SubscriberActivity extends Activity {

    private TextView textView;
    private Button button;
    private String ip = "192.168.111.120";
    private RosService rosService;
    private DemoSubscriber demoSubscriber = new DemoSubscriber();
    private Handler handler;
    private int offset;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);
        textView = findViewById(R.id.textview_show);
        button = findViewById(R.id.button_clear);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView.setText("");
            }
        });

        new RosClient(SubscriberActivity.this, ip, new OnTaskListener() {
            @Override
            public void onSuccess() {
                rosService= RosService.getRosServiceInstance(SubscriberActivity.this);
            }

            @Override
            public void onFailure(Exception e) {
                e.printStackTrace();
            }
        });

        IntentFilter intentFilter=new IntentFilter();
        intentFilter.addAction(BroadcastFilter.ROS_SHUTDOWN_FINISHED);
        intentFilter.addAction(BroadcastFilter.ROS_INIT_FINISHED);
        registerReceiver(rosServiceBroadcastRceiver, intentFilter);

        handler=new Handler();
    }

    private BroadcastReceiver rosServiceBroadcastRceiver =new BroadcastReceiver(){
        public void onReceive(Context context, Intent intent) {
            switch (intent.getAction()){
                case BroadcastFilter.ROS_SHUTDOWN_FINISHED:
                    break;
                case BroadcastFilter.ROS_INIT_FINISHED:
                    demoSubscriber.setStringListener(new DemoSubscriber.StringListener() {
                        @Override
                        public void onMessage(final String string) {

                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    textView.append(string+"\n");
                                }
                            });

                        }
                    });
                    rosService.addRosNode(demoSubscriber);
                    break;
            }
        }
    };

    @Override
    protected void onDestroy() {
        unregisterReceiver(rosServiceBroadcastRceiver);
        rosService.shutdownRosService();
        super.onDestroy();
    }
}
