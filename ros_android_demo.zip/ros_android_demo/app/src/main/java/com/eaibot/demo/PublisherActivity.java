package com.eaibot.demo;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.eaibot.constants.BroadcastFilter;
import com.eaibot.listener.OnTaskListener;
import com.eaibot.ros.RosClient;
import com.eaibot.ros.RosService;

/**
 * Created by EAIBOT on 2018/10/10.
 */

public class PublisherActivity extends Activity {

    private String TAG = PublisherActivity.class.getSimpleName();
    private EditText editText;
    private Button button;
    private String ip = "192.168.111.120";
    private RosService rosService;
    private boolean isInit = false;
    private DemoPublisher demoPublisher=new DemoPublisher();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pub);
        editText = findViewById(R.id.editText_msg);
        button = findViewById(R.id.button_send);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isInit) {
                    String data=editText.getText().toString();
                    demoPublisher.publishData(data);
                }
            }
        });


        IntentFilter intentFilter=new IntentFilter();
        intentFilter.addAction(BroadcastFilter.ROS_SHUTDOWN_FINISHED);
        intentFilter.addAction(BroadcastFilter.ROS_INIT_FINISHED);
        registerReceiver(rosServiceBroadcastRceiver, intentFilter);


        new RosClient(PublisherActivity.this, ip, new OnTaskListener() {
            @Override
            public void onSuccess() {
                rosService= RosService.getRosServiceInstance(PublisherActivity.this);
            }

            @Override
            public void onFailure(Exception e) {
                e.printStackTrace();
            }
        });


    }

    private BroadcastReceiver rosServiceBroadcastRceiver =new BroadcastReceiver(){
        public void onReceive(Context context, Intent intent) {
            switch (intent.getAction()){
                case BroadcastFilter.ROS_SHUTDOWN_FINISHED:
                    break;
                case BroadcastFilter.ROS_INIT_FINISHED:
                    isInit=true;
                    rosService.addRosNode(demoPublisher);
                    break;
            }
        }
    };

    @Override
    protected void onDestroy() {
        unregisterReceiver(rosServiceBroadcastRceiver);
        rosService.shutdownRosService();
        super.onDestroy();
    }
}
