package com.eaibot.demo;

import org.ros.message.MessageListener;
import org.ros.namespace.GraphName;
import org.ros.node.AbstractNodeMain;
import org.ros.node.ConnectedNode;
import org.ros.node.Node;
import org.ros.node.topic.Subscriber;

/**
 * Created by EAIBOT on 2018/10/10.
 */

public class DemoSubscriber extends AbstractNodeMain {

    private Subscriber<std_msgs.String> subscriber;
    private StringListener stringListener;
    private boolean isListener=false;

    public DemoSubscriber() {
    }

    public GraphName getDefaultNodeName() {
        return GraphName.of("eaibot_pubsub/subscriber");
    }

    interface StringListener{
        void onMessage(String string);
    }


    public void setStringListener(StringListener stringListener){
        isListener=true;
        this.stringListener=stringListener;
    }

    public void onStart(ConnectedNode connectedNode) {
        subscriber = connectedNode.newSubscriber("chatter", std_msgs.String._TYPE);
        subscriber.addMessageListener(new MessageListener<std_msgs.String>() {
            @Override
            public void onNewMessage(std_msgs.String string) {
                if(isListener){
                    stringListener.onMessage(string.getData());
                }
            }
        });
    }

    @Override
    public void onShutdown(Node node) {
        subscriber.shutdown();
    }
}
