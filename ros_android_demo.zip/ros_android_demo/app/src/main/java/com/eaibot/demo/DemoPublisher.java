package com.eaibot.demo;

import org.ros.namespace.GraphName;
import org.ros.node.AbstractNodeMain;
import org.ros.node.ConnectedNode;
import org.ros.node.Node;
import org.ros.node.topic.Publisher;

/**
 * Created by EAIBOT on 2018/10/10.
 */

public class DemoPublisher extends AbstractNodeMain {
    private String topic_name;
    private std_msgs.String str;
    private Publisher<std_msgs.String> publisher;

    public DemoPublisher() {
        this.topic_name = "chatter";
    }

    public DemoPublisher(String topic) {
        this.topic_name = topic;
    }

    public GraphName getDefaultNodeName() {
        return GraphName.of("eaibot_pubsub/publisher");
    }

    public void onStart(ConnectedNode connectedNode) {
        this.publisher = connectedNode.newPublisher(topic_name, std_msgs.String._TYPE);
        this.str = publisher.newMessage();
    }

    public void publishData(String data){
        str.setData(data);
        publisher.publish(str);
    }

    @Override
    public void onShutdown(Node node) {
        publisher.shutdown();
    }
}
